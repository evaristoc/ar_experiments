declare module 'cesium' {
    interface SampledProperty {
        maxNumSamples: number;
    }
    interface SampledPositionProperty {
        maxNumSamples: number;
    }
}
export {};
