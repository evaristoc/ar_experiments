declare const _default: (() => (uievent: UIEvent) => void) | (() => undefined);
export default _default;
