If you would like to contribute to the argonjs project, please fill out our [Contributor License Agreement](https://github.com/argonjs/argonjs.github.io/blob/master/CLA.md), either electornically (using the link on that page) or by printing, filling in, and mailing the form.

Our public roadmap for the project is on our [Trello board](https://trello.com/b/gBsEa8eg/argon-public-roadmap), if you would like ideas for how to help out.

We will add more information on our style guidelines and so on, as we move forward.  For now, please talk to us (ideally on our [Slack](http://argonjs.slack.com) for the project) and we can see how best to collaborate.
