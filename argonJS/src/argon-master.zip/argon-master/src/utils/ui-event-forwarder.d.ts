import { ViewService } from '../view';
export default function createEventForwarder(this: void, viewService: ViewService, callback: (uievent: UIEvent) => void): void;
