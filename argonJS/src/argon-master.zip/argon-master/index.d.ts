/// <reference path="types/declarations.d.ts" />
export * from './src/argon'
export as namespace Argon;