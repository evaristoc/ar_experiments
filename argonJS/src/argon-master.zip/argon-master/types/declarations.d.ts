declare module '*package.json' {
    export const version : string;
}

declare module 'googlevr/webvr-polyfill/src/cardboard-ui';